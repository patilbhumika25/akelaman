<?php
/**
 * Plugin Name: Akela Mann — Booking & Admin
 * Plugin URI:  https://akelamann.com
 * Description: Adds shortcodes, booking form helper, and admin enhancements for the Akela Mann theme.
 * Version:     1.0.0
 * Author:      Nishant Hemrajani
 * Text Domain: akela-mann-plugin
 */

if (!defined('ABSPATH')) exit;

// ── Shortcode: [akela_booking_form] ───────────────────────────────────
function akela_booking_shortcode() {
    ob_start();
    $nonce = wp_create_nonce('akela_nonce');
    ?>
    <div class="booking-types" style="margin-bottom:24px;">
        <div class="booking-type active" data-type="Talking Session"><div class="icon">🗣️</div><h4>Talking Session</h4><p>1-on-1</p></div>
        <div class="booking-type" data-type="Support Group"><div class="icon">👥</div><h4>Support Group</h4><p>Group</p></div>
        <div class="booking-type" data-type="Mindfulness Workshop"><div class="icon">🧘</div><h4>Workshop</h4><p>Guided</p></div>
    </div>
    <form id="booking-form-sc" class="glass-card">
        <input type="hidden" name="action" value="akela_booking">
        <input type="hidden" name="nonce" value="<?php echo $nonce; ?>">
        <input type="hidden" id="sc_session_type" name="session_type" value="Talking Session">
        <div class="form-row">
            <div class="form-group"><label>Full Name *</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Phone *</label><input type="tel" name="phone" required></div>
            <div class="form-group"><label>Preferred Date *</label><input type="date" name="session_date" required min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>"></div>
        </div>
        <div class="form-group">
            <label>Preferred Time *</label>
            <select name="session_time" required>
                <option value="">Select…</option>
                <option>09:00 – 10:00 am</option>
                <option>10:00 – 11:00 am</option>
                <option>11:00 am – 12:00 pm</option>
                <option>2:00 – 3:00 pm</option>
                <option>3:00 – 4:00 pm</option>
                <option>4:00 – 5:00 pm</option>
            </select>
        </div>
        <div class="form-group"><label>Message (optional)</label><textarea name="message"></textarea></div>
        <button type="submit" class="btn btn-primary" style="width:100%;">Confirm Booking ✨</button>
    </form>
    <script>
    (function(){
        document.querySelectorAll('.booking-type').forEach(b=>{
            b.addEventListener('click',function(){
                document.querySelectorAll('.booking-type').forEach(x=>x.classList.remove('active'));
                this.classList.add('active');
                document.getElementById('sc_session_type').value = this.dataset.type;
            });
        });
        document.getElementById('booking-form-sc')?.addEventListener('submit',function(e){
            e.preventDefault();
            const btn=this.querySelector('button');
            btn.textContent='Confirming…'; btn.disabled=true;
            fetch('<?php echo admin_url("admin-ajax.php"); ?>',{method:'POST',body:new FormData(this)})
            .then(r=>r.json()).then(d=>{
                if(d.success){this.innerHTML='<div style="text-align:center;padding:48px"><div style="font-size:3rem">🌙</div><h3 style="color:#c9b8e8;font-family:Georgia,serif">Session Booked!</h3><p>We\'ll confirm via Email/WhatsApp within 24 hours.</p></div>';}
                else{btn.textContent='Confirm Booking ✨';btn.disabled=false;}
            });
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('akela_booking_form', 'akela_booking_shortcode');

// ── Shortcode: [akela_contact_form] ───────────────────────────────────
function akela_contact_shortcode() {
    ob_start();
    $nonce = wp_create_nonce('akela_nonce');
    ?>
    <form id="contact-form-sc" class="glass-card">
        <input type="hidden" name="action" value="akela_contact">
        <input type="hidden" name="nonce" value="<?php echo $nonce; ?>">
        <div class="form-row">
            <div class="form-group"><label>Name *</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" required></div>
        </div>
        <div class="form-group"><label>Message *</label><textarea name="message" required></textarea></div>
        <button type="submit" class="btn btn-primary" style="width:100%;">Send Message ✉️</button>
    </form>
    <script>
    document.getElementById('contact-form-sc')?.addEventListener('submit',function(e){
        e.preventDefault();
        const btn=this.querySelector('button');
        btn.textContent='Sending…';btn.disabled=true;
        fetch('<?php echo admin_url("admin-ajax.php"); ?>',{method:'POST',body:new FormData(this)})
        .then(r=>r.json()).then(d=>{
            if(d.success){this.innerHTML='<div style="text-align:center;padding:48px"><div style="font-size:3rem">✨</div><h3>Message Sent!</h3></div>';}
            else{btn.textContent='Send Message ✉️';btn.disabled=false;}
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('akela_contact_form', 'akela_contact_shortcode');

// ── Shortcode: [akela_stats] ──────────────────────────────────────────
function akela_stats_shortcode($atts) {
    $atts = shortcode_atts(['people'=>'5000','sessions'=>'200','groups'=>'50','cities'=>'15'], $atts);
    return '<div class="stats-strip"><div class="container"><div class="stats-grid">
        <div class="stat-item"><div class="stat-number" data-count="'.$atts['people'].'">'.$atts['people'].'</div><div class="stat-label">People Helped</div></div>
        <div class="stat-item"><div class="stat-number" data-count="'.$atts['sessions'].'">'.$atts['sessions'].'</div><div class="stat-label">Sessions</div></div>
        <div class="stat-item"><div class="stat-number" data-count="'.$atts['groups'].'">'.$atts['groups'].'</div><div class="stat-label">Support Groups</div></div>
        <div class="stat-item"><div class="stat-number" data-count="'.$atts['cities'].'">'.$atts['cities'].'</div><div class="stat-label">Cities</div></div>
    </div></div></div>';
}
add_shortcode('akela_stats', 'akela_stats_shortcode');

// ── Admin: Add Booking Status Column ──────────────────────────────────
add_filter('manage_booking_posts_columns', function($cols){
    $cols['status'] = 'Status'; $cols['session_date'] = 'Session Date'; return $cols;
});
add_action('manage_booking_posts_custom_column', function($col, $id){
    if ($col === 'status') {
        $s = get_post_meta($id,'_status',true) ?: 'Pending';
        $c = $s==='Confirmed'?'green':($s==='Cancelled'?'red':'orange');
        echo '<span style="color:'.$c.';font-weight:600;">'.$s.'</span>';
    }
    if ($col === 'session_date') echo esc_html(get_post_meta($id,'_client_session_date',true));
}, 10, 2);

// ── Flush Rewrite Rules on Activation ────────────────────────────────
register_activation_hook(__FILE__, function(){ flush_rewrite_rules(); });
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(); });
